using System.Globalization;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Reactive;

namespace SpaceSharp.Controls;

/// <summary>A clickable row of labeled ticks.</summary>
/// <remarks><see cref="Selected"/> is -1 when the current value is not a tick.</remarks>
public sealed class TickScale : Control
{
    public static readonly StyledProperty<IReadOnlyList<string>> LabelsProperty =
        AvaloniaProperty.Register<TickScale, IReadOnlyList<string>>(nameof(Labels), Array.Empty<string>());

    public static readonly StyledProperty<int> SelectedProperty =
        AvaloniaProperty.Register<TickScale, int>(nameof(Selected), 0);

    /// <summary>True lights the line from the picked tick to the right end; false from the left end to it.</summary>
    public static readonly StyledProperty<bool> SpanToEndProperty =
        AvaloniaProperty.Register<TickScale, bool>(nameof(SpanToEnd), true);

    public IReadOnlyList<string> Labels
    {
        get => GetValue(LabelsProperty); set => SetValue(LabelsProperty, value);
    }
    public int Selected
    {
        get => GetValue(SelectedProperty); set => SetValue(SelectedProperty, value);
    }
    public bool SpanToEnd
    {
        get => GetValue(SpanToEndProperty); set => SetValue(SpanToEndProperty, value);
    }

    /// <summary>Raised with the index of the clicked tick.</summary>
    public event Action<int>? Picked;

    private const double LineY = 10, TickTop = 5, TickBottom = 16, LabelY = 22, SidePad = 18;
    private int _hover = -1;

    static TickScale()
    {
        AffectsRender<TickScale>(LabelsProperty, SelectedProperty, SpanToEndProperty);
    }

    public TickScale()
    {
        Height = 40;
        Cursor = new Cursor(StandardCursorType.Hand);
        ClipToBounds = false;
        // redraw on theme change
        foreach (string? key in new[] { "Accent", "Stroke", "TextDim", "Text" })
        {
            this.GetResourceObservable(key).Subscribe(new AnonymousObserver<object?>(_ => InvalidateVisual()));
        }
    }

    private double TickX(int i) => Labels.Count < 2 ? SidePad : SidePad + (Bounds.Width - 2 * SidePad) * i / (Labels.Count - 1);

    private int NearestTick(double x)
    {
        int best = 0;
        double bestDist = double.MaxValue;
        for (int i = 0; i < Labels.Count; i++)
        {
            double d = Math.Abs(TickX(i) - x);
            if (d < bestDist)
            {
                bestDist = d;
                best = i;
            }
        }
        return best;
    }

    protected override void OnPointerPressed(PointerPressedEventArgs e)
    {
        base.OnPointerPressed(e);
        if (Labels.Count == 0)
        {
            return;
        }
        Picked?.Invoke(NearestTick(e.GetPosition(this).X));
        e.Handled = true;
    }

    protected override void OnPointerMoved(PointerEventArgs e)
    {
        base.OnPointerMoved(e);
        int h = Labels.Count == 0 ? -1 : NearestTick(e.GetPosition(this).X);
        if (h != _hover)
        {
            _hover = h;
            InvalidateVisual();
        }
    }

    protected override void OnPointerExited(PointerEventArgs e)
    {
        base.OnPointerExited(e);
        if (_hover != -1)
        {
            _hover = -1;
            InvalidateVisual();
        }
    }

    private IBrush Brush(string key, IBrush fallback) => this.FindResource(key) as IBrush ?? fallback;

    public override void Render(DrawingContext context)
    {
        base.Render(context);
        int n = Labels.Count;
        if (n == 0)
        {
            return;
        }
        IBrush stroke = Brush("Stroke", Brushes.Gray);
        IBrush accent = Brush("Accent", Brushes.Orange);
        IBrush dim = Brush("TextDim", Brushes.Gray);
        var typeface = new Typeface(TextElement.GetFontFamily(this));

        double left = TickX(0), right = TickX(n - 1);
        context.DrawLine(new Pen(stroke, 2), new Point(left, LineY), new Point(right, LineY));

        // tick 0 is "any": nothing lights up
        int sel = Selected;
        bool set = sel > 0 && sel < n;
        if (set)
        {
            double x = TickX(sel);
            double from = SpanToEnd ? x : left, to = SpanToEnd ? right : x;
            if (to > from)
            {
                context.DrawLine(new Pen(accent, 2), new Point(from, LineY), new Point(to, LineY));
            }
        }

        IBrush textBrush = Brush("Text", Brushes.White);
        for (int i = 0; i < n; i++)
        {
            double x = TickX(i);
            bool picked = i == sel;
            bool lit = set && (SpanToEnd ? i >= sel : i <= sel);
            if (picked)
            {
                context.DrawRectangle(set ? accent : dim, null, new RoundedRect(new Rect(x - 2, TickTop - 3, 4, TickBottom - TickTop + 6), 2));
            }
            else
            {
                context.DrawLine(new Pen(lit ? accent : stroke, 2), new Point(x, TickTop), new Point(x, TickBottom));
            }
            if (i == _hover && !picked)
            {
                context.DrawEllipse(null, new Pen(accent, 1), new Point(x, LineY), 6, 6);
            }

            var text = new FormattedText(Labels[i], CultureInfo.CurrentCulture, FlowDirection.LeftToRight, typeface, 11, picked ? (set ? accent : textBrush) : dim);
            if (picked)
            {
                text.SetFontWeight(FontWeight.SemiBold);
            }
            double tx = Math.Clamp(x - text.Width / 2, 0, Math.Max(0, Bounds.Width - text.Width));
            context.DrawText(text, new Point(tx, LabelY));
        }
    }
}
